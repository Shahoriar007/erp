<?php

/**
 *	User Helpers
 */
