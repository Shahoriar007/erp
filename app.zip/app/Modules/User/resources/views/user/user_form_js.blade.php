@section('js')
<script src="{{asset('assets/admin/js/jquery.validate.min.js')}}"></script>
<script src="{{asset('core/app/modules/user/js/user.js')}}"></script>
@include('vendor.sweetalert2.sweetalert2_js')
@endsection
