@section('header-resource1')
    <link rel="stylesheet" href="{{asset('assets/admin/css/datatable.css')}}">
    <link rel="stylesheet" href="{{asset('assets/common/select2/css/select2.min.css')}}">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
@endsection
