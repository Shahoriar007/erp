<?php return array (
  'complain.complain-form' => 'App\\Http\\Livewire\\Complain\\ComplainForm',
  'complain.complain-form-edit' => 'App\\Http\\Livewire\\Complain\\ComplainFormEdit',
  'meal.meal-form' => 'App\\Http\\Livewire\\Meal\\MealForm',
  'member.member-form' => 'App\\Http\\Livewire\\Member\\MemberForm',
  'member.member-form-edit' => 'App\\Http\\Livewire\\Member\\MemberFormEdit',
  'transection.earn-form' => 'App\\Http\\Livewire\\Transection\\EarnForm',
  'transection.earn-form-edit' => 'App\\Http\\Livewire\\Transection\\EarnFormEdit',
  'transection.spend-form' => 'App\\Http\\Livewire\\Transection\\SpendForm',
  'transection.spend-form-edit' => 'App\\Http\\Livewire\\Transection\\SpendFormEdit',
);